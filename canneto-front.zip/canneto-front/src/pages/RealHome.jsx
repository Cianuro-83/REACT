const RealHome = () => {
	return <div className="rfc-RealHome"></div>;
};

export default RealHome;

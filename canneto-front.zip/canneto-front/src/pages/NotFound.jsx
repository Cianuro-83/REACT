const NotFound = () => {
	return <h2>La Pagina non esiste</h2>;
};

export default NotFound;

const ComeRaggingerci = () => {
	return (
		<div className="rfc-ComeRaggingerci">
			<h1 className="text-center text-uppercase fw-bolder">
				come raggiungerci
			</h1>
		</div>
	);
};

export default ComeRaggingerci;

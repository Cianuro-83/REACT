const PellegrinaggioCompagnie = () => {
	return (
		<div className="rfc-PellegrinaggioCompagnie">
			<h1 className="text-center text-uppercase fw-bolder">
				elenco compagnie
			</h1>
		</div>
	);
};

export default PellegrinaggioCompagnie;
